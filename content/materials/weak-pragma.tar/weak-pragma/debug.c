#include "stdio.h"

void debug(char * str){
    printf("[DEBUG] %s\n", str);
}
