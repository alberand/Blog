#include <stdio.h>
#include "foo.h"

int main(void){
    printf("Hello\n");

	foo();

    return 0;
}
